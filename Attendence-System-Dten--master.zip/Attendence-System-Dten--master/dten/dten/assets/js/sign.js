// $(document).ready(function()
// {
//    $("#teacher").show();
//    $("#student").hide();
    
//    $( "#profession" ).change(function() 
//   {
//       if (this.value == "student") {
//         $("#teacher").hide(1000);     
//         $("#student").show(1000);
//       }
//       else{
//         $("#student").hide(1000);
//         $("#teacher").show(1000);     
//       }
//    });
 
// });  