
$(document).ready(function()
{
  // $("#floatLogo").fadeIn(1000); 
  
  // $("#moreinfo").fadeIn(1000);

  // $("#sign-in-div").fadeIn(1000);  
  
  // $("#tagline").hide(1000);  
  // $("#tagline").show(1000);  
  
  // for(var i=0;i<1000;i++)
  // {
  //   $("#tagline").fadeOut(1000);  
  //   $("#tagline").fadeIn(1000);    
  // }
 
  // $( "#sign-in" ).click(function() 
  // {
  //     $(this).attr("disabled", "disabled");
  //  });
  
});  