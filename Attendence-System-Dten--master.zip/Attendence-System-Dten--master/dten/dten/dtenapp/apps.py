from django.apps import AppConfig


class DtenappConfig(AppConfig):
    name = 'dtenapp'
